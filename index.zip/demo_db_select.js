var mysql = require('mysql');

var con = mysql.createConnection({
  host: "hostname",
  user: "username",
  password: "password",
  database: "db-name"
});


	var select= "SELECT temp FROM temp_values ORDER BY temp DESC LIMIT 1";
	function checkError(err, result) {
  	  if (err) throw err;
   	 return result[0].temp+'';
   	 

  	}

	function mainline(err) {
  	if (err) throw err;
  	console.log("connected");

  	con.query(select, checkError);

	console.log("this should be query"+someVar);
	return someVar;
	}

	con.connect(mainline);
	var someVar=mainline();

	
console.log(someVar);
console.log("end");
 